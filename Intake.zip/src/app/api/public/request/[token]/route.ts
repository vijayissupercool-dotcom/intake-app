import { NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params;
  const supabase = await createServiceClient();

  const { data: req, error } = await supabase
    .from("requests")
    .select("id, title, description, max_files, max_file_size_mb, allowed_file_types, expires_at, upload_count, active")
    .eq("token", token)
    .eq("active", true)
    .single();

  if (error || !req) {
    return NextResponse.json(
      { error: "Request not found or inactive" },
      { status: 404 }
    );
  }

  // Check expiration
  if (req.expires_at && new Date(req.expires_at) < new Date()) {
    return NextResponse.json(
      { error: "This request has expired" },
      { status: 410 }
    );
  }

  return NextResponse.json({ request: req });
}

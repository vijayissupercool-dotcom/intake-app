import { NextRequest, NextResponse } from "next/server";
import { processTransfer } from "@/lib/transfer/worker";
import { createServiceClient } from "@/lib/supabase/server";

interface PendingUpload {
  id: string;
  r2_key: string;
  file_name: string;
  file_type: string;
  file_size: number;
  request_id: string;
  requests: { user_id: string }[];
}

export async function POST(request: NextRequest) {
  const authHeader = request.headers.get("authorization");
  const expectedAuth = `Bearer ${process.env.TRANSFER_WORKER_SECRET}`;

  if (!authHeader || authHeader !== expectedAuth) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const supabase = await createServiceClient();

  // Support both single-upload dispatch (from client) and batch (from worker)
  let body: { uploadId?: string } = {};
  try {
    body = await request.json();
  } catch {
    // body optional
  }

  // Case 1: explicit uploadId — process just that upload
  if (body.uploadId) {
    const { data: upload, error: uploadError } = await supabase
      .from("uploads")
      .select(
        `id, r2_key, file_name, file_type, file_size, request_id, status, requests (user_id)`
      )
      .eq("id", body.uploadId)
      .single();

    if (uploadError || !upload) {
      return NextResponse.json({ error: "Upload not found" }, { status: 404 });
    }

    if (upload.status !== "uploaded") {
      return NextResponse.json(
        { error: `Upload status is ${upload.status}, expected uploaded` },
        { status: 400 }
      );
    }

    try {
      const result = await processTransfer(buildJob(upload));
      return NextResponse.json(result);
    } catch (error) {
      console.error("Transfer failed:", error);
      return NextResponse.json(
        {
          error: "Transfer failed",
          message: error instanceof Error ? error.message : "Unknown error",
        },
        { status: 500 }
      );
    }
  }

  // Case 2: no uploadId — process all pending uploads (worker schedule)
  const { data: pending, error: pendingError } = await supabase
    .from("uploads")
    .select(
      `id, r2_key, file_name, file_type, file_size, request_id, status, requests (user_id)`
    )
    .eq("status", "uploaded")
    .limit(50);

  if (pendingError) {
    return NextResponse.json(
      { error: pendingError.message },
      { status: 500 }
    );
  }

  const results = { succeeded: 0, failed: 0, skipped: 0 };
  for (const upload of (pending || []) as PendingUpload[]) {
    try {
      await processTransfer(buildJob(upload));
      results.succeeded++;
    } catch {
      results.failed++;
    }
  }

  return NextResponse.json({ results, pending: (pending || []).length });
}

function buildJob(upload: PendingUpload) {
  return {
    uploadId: upload.id,
    r2Key: upload.r2_key,
    fileName: upload.file_name,
    fileType: upload.file_type,
    fileSize: upload.file_size,
    requestId: upload.request_id,
    userId: upload.requests?.[0]?.user_id ?? "",
  };
}

import { NextRequest, NextResponse } from "next/server";
import { processTransfer } from "@/lib/transfer/worker";
import { createServiceClient } from "@/lib/supabase/server";

/**
 * Called by the public upload page AFTER the file is successfully uploaded
 * to R2. This runs server-side so no worker secret is ever exposed to the
 * browser. It marks the upload as "uploaded" and dispatches the transfer.
 */
export async function POST(request: NextRequest) {
  const { uploadId } = await request.json();

  if (!uploadId) {
    return NextResponse.json({ error: "uploadId is required" }, { status: 400 });
  }

  const supabase = await createServiceClient();

  const { data: upload, error: uploadError } = await supabase
    .from("uploads")
    .select(
      `id, r2_key, file_name, file_type, file_size, request_id, status, requests (user_id)`
    )
    .eq("id", uploadId)
    .single();

  if (uploadError || !upload) {
    return NextResponse.json({ error: "Upload not found" }, { status: 404 });
  }

  if (upload.status !== "pending" && upload.status !== "uploading") {
    return NextResponse.json(
      { error: `Upload status is ${upload.status}, cannot transfer` },
      { status: 400 }
    );
  }

  try {
    // Mark as uploaded, then transfer server-side
    await supabase.from("uploads").update({ status: "uploaded" }).eq("id", uploadId);

    const result = await processTransfer({
      uploadId: upload.id,
      r2Key: upload.r2_key,
      fileName: upload.file_name,
      fileType: upload.file_type,
      fileSize: upload.file_size,
      requestId: upload.request_id,
      userId: (upload.requests as unknown as { user_id: string }[])?.[0]?.user_id ?? "",
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error("Transfer failed:", error);
    return NextResponse.json(
      {
        error: "Transfer failed",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}

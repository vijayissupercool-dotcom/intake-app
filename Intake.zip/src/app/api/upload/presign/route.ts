import { NextRequest, NextResponse } from "next/server";
import { getPresignedUploadUrl } from "@/lib/r2/client";
import { createServiceClient } from "@/lib/supabase/server";
import { uploadMetadataSchema } from "@/lib/validators";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const parsed = uploadMetadataSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { requestId, fileName, fileSize, fileType, uploaderName, uploaderEmail } =
    parsed.data;

  const supabase = await createServiceClient();

  // Verify the request exists and is active
  const { data: req, error: reqError } = await supabase
    .from("requests")
    .select("*")
    .eq("id", requestId)
    .eq("active", true)
    .single();

  if (reqError || !req) {
    return NextResponse.json(
      { error: "Request not found or inactive" },
      { status: 404 }
    );
  }

  // Check expiration
  if (req.expires_at && new Date(req.expires_at) < new Date()) {
    return NextResponse.json(
      { error: "This request has expired" },
      { status: 410 }
    );
  }

  // Check file count limit
  if (req.upload_count >= req.max_files) {
    return NextResponse.json(
      { error: "This request has reached its file limit" },
      { status: 410 }
    );
  }

  // Check file size limit
  const maxFileSizeBytes = req.max_file_size_mb * 1024 * 1024;
  if (fileSize > maxFileSizeBytes) {
    return NextResponse.json(
      { error: `File size exceeds the ${req.max_file_size_mb} MB limit` },
      { status: 413 }
    );
  }

  // Check file type if restricted
  if (req.allowed_file_types && req.allowed_file_types.length > 0) {
    const allowed = req.allowed_file_types.some(
      (type: string) => fileType === type || fileType.startsWith(type.replace("/*", ""))
    );
    if (!allowed) {
      return NextResponse.json(
        { error: "File type not allowed for this request" },
        { status: 415 }
      );
    }
  }

  // Generate R2 key
  const timestamp = Date.now();
  const safeFileName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const r2Key = `uploads/${requestId}/${timestamp}_${safeFileName}`;

  // Get presigned URL
  const presignedUrl = await getPresignedUploadUrl({
    key: r2Key,
    contentType: fileType,
    expiresIn: 3600, // 1 hour
  });

  // Create upload record
  const { data: upload, error: uploadError } = await supabase
    .from("uploads")
    .insert({
      request_id: requestId,
      file_name: fileName,
      file_size: fileSize,
      file_type: fileType,
      r2_key: r2Key,
      status: "pending",
      uploader_name: uploaderName || null,
      uploader_email: uploaderEmail || null,
    })
    .select()
    .single();

  if (uploadError) {
    return NextResponse.json({ error: uploadError.message }, { status: 500 });
  }

  return NextResponse.json({
    uploadId: upload.id,
    presignedUrl,
    r2Key,
  });
}

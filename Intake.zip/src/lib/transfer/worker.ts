import { deleteObject } from "@/lib/r2/client";
import {
  getDriveClient,
  refreshAccessToken,
  uploadFileToDrive,
} from "@/lib/drive/client";
import { createServiceClient } from "@/lib/supabase/server";
import { createNotification } from "@/lib/notifications";
import { sendNewUploadEmail } from "@/lib/email/templates";
import { env } from "@/lib/config/env";

interface TransferJob {
  uploadId: string;
  r2Key: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  requestId: string;
  userId: string;
}

export async function processTransfer(job: TransferJob) {
  const supabase = await createServiceClient();

  try {
    // 1. Mark upload as transferring
    await supabase
      .from("uploads")
      .update({ status: "transferring" })
      .eq("id", job.uploadId);

    // 2. Get the user's Google tokens
    const { data: connection, error: connError } = await supabase
      .from("google_connections")
      .select("*")
      .eq("user_id", job.userId)
      .single();

    if (connError || !connection) {
      throw new Error("Google Drive not connected");
    }

    // 3. Refresh access token if needed
    let accessToken = connection.access_token;
    const refreshToken = connection.refresh_token;

    if (
      connection.token_expiry &&
      new Date(connection.token_expiry) < new Date(Date.now() + 5 * 60 * 1000)
    ) {
      const refreshed = await refreshAccessToken(refreshToken);
      accessToken = refreshed.access_token!;

      await supabase
        .from("google_connections")
        .update({
          access_token: refreshed.access_token,
          token_expiry: refreshed.expiry_date
            ? new Date(refreshed.expiry_date).toISOString()
            : null,
        })
        .eq("user_id", job.userId);
    }

    // 4. Get request to find target folder
    const { data: request } = await supabase
      .from("requests")
      .select("drive_folder_id")
      .eq("id", job.requestId)
      .single();

    if (!request?.drive_folder_id) {
      throw new Error("Request folder not found");
    }

    // 5. Download from R2
    const fileBuffer = await downloadFileBuffer(job.r2Key);

    // 6. Upload to Google Drive
    const drive = getDriveClient({
      access_token: accessToken,
      refresh_token: refreshToken,
    });
    const driveFile = await uploadFileToDrive(
      drive,
      fileBuffer,
      job.fileName,
      job.fileType,
      request.drive_folder_id
    );

    // 7. Mark upload as completed
    await supabase
      .from("uploads")
      .update({
        status: "completed",
        drive_file_id: driveFile.id,
        drive_file_url: `https://drive.google.com/file/d/${driveFile.id}/view`,
        completed_at: new Date().toISOString(),
      })
      .eq("id", job.uploadId);

    // 8. Clean up R2 object
    await deleteObject(job.r2Key);

    // 9. Update request upload count
    await supabase.rpc("increment_upload_count", {
      request_id: job.requestId,
    });

    // 10. Create in-app notification
    await createNotification({
      userId: job.userId,
      type: "upload_completed",
      title: "New file received",
      message: `"${job.fileName}" was added to your request.`,
      metadata: {
        uploadId: job.uploadId,
        requestId: job.requestId,
        driveFileId: driveFile.id,
      },
    });

    // 11. Send email notification if enabled
    try {
      const { data: requestMeta } = await supabase
        .from("requests")
        .select("notify_email, title")
        .eq("id", job.requestId)
        .single();

      if (requestMeta?.notify_email) {
        const { data: userProfile } = await supabase
          .from("users")
          .select("email")
          .eq("id", job.userId)
          .single();

        if (userProfile?.email) {
          await sendNewUploadEmail({
            toEmail: userProfile.email,
            requestTitle: requestMeta.title,
            fileName: job.fileName,
            fileSizeMb: (job.fileSize / 1024 / 1024).toFixed(2) + " MB",
            requestUrl: `${env.app.url}/requests/${job.requestId}`,
          });
        }
      }
    } catch (emailError) {
      console.error("Failed to send notification email:", emailError);
    }

    return { success: true, driveFileId: driveFile.id };
  } catch (error) {
    // Mark upload as failed
    await supabase
      .from("uploads")
      .update({
        status: "failed",
        error_message:
          error instanceof Error ? error.message : "Unknown error",
      })
      .eq("id", job.uploadId);

    throw error;
  }
}

async function downloadFileBuffer(key: string): Promise<Buffer> {
  const { downloadFileFromR2 } = await import("@/lib/r2/client");
  return downloadFileFromR2(key);
}
